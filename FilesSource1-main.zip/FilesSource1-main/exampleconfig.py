from sample_config import Config


class Development(Config):
    # ضـع اكـوادك تحت مكـان الكـلام العـربي  .. امسـح الكلام العربي وضع اكوادك
    APP_ID = 6
    API_HASH = "ضع كود الايبي هاش"
    ALIVE_NAME = "اسم حسابك التلي"
    DB_URI = "رابـط التخـزين الخـاص بك"
    STRING_SESSION = "كود تيرمــكس"
    TG_BOT_TOKEN = "توكـن البـوت الخـاص بك"
    PRIVATE_GROUP_BOT_API_ID = -100
    COMMAND_HAND_LER = "."
    SUDO_COMMAND_HAND_LER = "،"
    TZ = "Asia/Baghdad"
